﻿namespace TreeGenerator {
    
    
    public partial class TreeData {
        partial class TreeDataTableDataTable
        {
        }
    }
}
